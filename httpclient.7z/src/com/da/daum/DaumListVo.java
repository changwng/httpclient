package com.da.daum;

public class DaumListVo {
 private String subject;
 private String idAlais;
 private String creatYmd;
 private String viewUrl;
 private String content;
 private String rnum;
 
 
public String getContent() {
	return content;
}
public void setContent(String content) {
	this.content = content;
}
public String getSubject() {
	return subject;
}
public void setSubject(String subject) {
	this.subject = subject;
}
public String getIdAlais() {
	return idAlais;
}
public void setIdAlais(String idAlais) {
	this.idAlais = idAlais;
}
public String getCreatYmd() {
	return creatYmd;
}
public void setCreatYmd(String creatYmd) {
	this.creatYmd = creatYmd;
}
public String getViewUrl() {
	return viewUrl;
}
public void setViewUrl(String viewUrl) {
	this.viewUrl = viewUrl;
}
public String getRnum() {
	return rnum;
}
public void setRnum(String rnum) {
	this.rnum = rnum;
} 
 
 
}
