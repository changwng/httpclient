package com.da.img;

public class AuthorVo {
 private String authorId;
 private String authorAlias;
 private String authorSpan;
public String getAuthorId() {
	return authorId;
}
public void setAuthorId(String authorId) {
	this.authorId = authorId;
}
public String getAuthorAlias() {
	return authorAlias;
}
public void setAuthorAlias(String authorAlias) {
	this.authorAlias = authorAlias;
}
public String getAuthorSpan() {
	return authorSpan;
}
public void setAuthorSpan(String authorSpan) {
	this.authorSpan = authorSpan;
}
 
}
